#!/bin/bash

# Ranges:
# 192.168.1-12.0/24
#
# DONT TOUCH 254 on all ranges
# Team 6 left Round 1, so 192.168.6.0/24 will be live but unused


wget -m 192.168.6.11:80 &
wget -m 192.168.6.12:80 &
wget -m 192.168.6.13:80 &
wget -m 192.168.6.13:8080 &
wget -m 192.168.6.16:80 &
wget -m 192.168.6.18:80 &
